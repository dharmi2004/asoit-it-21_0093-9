class Rectengle {
    constructor(height,weight) {
        this.height=height;
        this.weight=weight;
    }
}

var n=new Rectengle(10,20);
document.write(n instanceof Rectengle);
document.write("<br/>");
document.write(n.height+n.weight);