let s="It's";
let s1 = "Gaurav";
let s2 = "Kathiriya";
let emoji=String.fromCodePoint(0x1F621);
let s3 =  s+ " "+s1 + " " + s2+ " " + emoji;
document.write(s3);